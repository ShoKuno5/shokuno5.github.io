# Blog Posts Code Package

This package contains all the code needed to implement the blog posts functionality with KaTeX math support and citations.

## Structure

- `src/content/posts/` - Blog post content (markdown files)
- `src/layouts/` - Post layouts including citation support
- `src/pages/posts/` - Dynamic routing for posts
- `src/utils/` - Utilities for citations and processing
- `src/components/` - Components for citations
- `src/styles/` - Global styles including math equation styling
- Configuration files for Astro and content collections

## Setup Instructions

1. Install dependencies:
   ```bash
   npm install remark-math rehype-katex katex
   npm install @astrojs/mdx @astrojs/tailwind
   npm install citation-js bibtex-parse-js
   ```

2. Copy all files to your Astro project

3. Update `astro.config.mjs` with the provided configuration

4. Run `npm run dev` to start the development server

## Features

- Bilingual support (English/Japanese)
- KaTeX math equation rendering
- Academic citations with BibTeX support
- Multiple post layouts
- Tag system
- Reading time calculation
- Responsive design
EOF < /dev/null