---
title: Math test
pubDate: 2025-01-03
tags: ["test"]
description: "Testing math rendering"
---

インライン: $E=mc^2$

ブロック:

$$
\int_{a}^{b} f(x)\,dx
$$

もう一つのインライン例: $a^2 + b^2 = c^2$

複雑な式:

$$
\mathcal{F}[f(t)] = F(\omega) = \int_{-\infty}^{\infty} f(t) e^{-i\omega t} \, dt
$$